# Happy 21st Birthday Website

## Use it
Open `index.html` in any browser.

## Edit it directly on the website
Click the small **✎ Edit** button in the bottom-right corner.
You can change:
- her name
- the main heading
- the intro
- the birthday letter
- the signature

Click **Save changes**. The changes are saved in that browser using local storage.

## Coupons
To change the coupons, edit the `coupons` list near the bottom of `index.html`.
The coupon editor is kept separate so the birthday girl does not accidentally change the coupons.

## Important about the website link
This package is the website itself; it does not automatically create a public internet URL.
For a short, easy-to-copy public address, publish `index.html` on a free static host such as GitHub Pages.
A simple filename like `index.html` means the page opens directly at the site's main address.
